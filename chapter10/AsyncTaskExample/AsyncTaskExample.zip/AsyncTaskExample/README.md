# AsyncTask-Example
Example for Android AsyncTask

AsyncTask的例子
![](https://github.com/HBU/AndroidDemo/blob/master/chapter10/AsyncTaskExample/show.png?raw=true)
