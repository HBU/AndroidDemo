# BroadCast Life cycle
![](https://github.com/HBU/AndroidDemo/blob/master/chapter07/broadcast/13.png)
